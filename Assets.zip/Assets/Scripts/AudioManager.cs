using Ricimi;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    // Start is called before the first frame update
    private AudioSource BGM;
    public SpriteSwapper ��ť;
    void Start()
    {
        BGM = GameObject.Find("Canvas").GetComponent<AudioSource>();
        int p = PlayerPrefs.GetInt("isPlay", 1);
        if (p == 1)
        {
            if(!BGM.isPlaying)
            BGM.Play();
        }
        else

        {
            BGM.Pause();
            ��ť.SwapSprite();
        }
    }

    public void ����()
    {
        if (PlayerPrefs.GetInt("isPlay", 1) == 1)
        {
            PlayerPrefs.SetInt("isPlay", 0);
            BGM.Pause();
        }
          
        else
        {
            PlayerPrefs.SetInt("isPlay", 1);
            if (!BGM.isPlaying)
                BGM.Play();
        }
         

    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
