using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class openPage : MonoBehaviour
{
    // Start is called before the first frame update
    private Transform Canvas;
    public GameObject ҳ��;
    public GameObject ��ǰҳ��;
    void Start()
    {
        Canvas = GameObject.Find("Canvas").transform;
    }
    public void ��ҳ��()
    {
        GameObject ��ǰҳ = Instantiate(ҳ��, Canvas);
        ��ǰҳ.SetActive(true);
        Destroy(��ǰҳ��);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
